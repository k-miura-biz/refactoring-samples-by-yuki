## What's this machine ?

このディレクトリは、
マシン:ncms-server-002
設定用のものです。

## 用途

ひとまず「本番環境の類似環境再現用」のものとします。

## Network関連

ip:10.149.28.50
defaultgetawary:10.149.28.1
dns:10.117.1.200

