# gitlabを試験的にDocker内で立ち上げるスクリプト
# 
# ３つのDockerコンテナを使い、GitLabを立ち上げる。
# 
# 前提
#   作業はすべてrootで行う事。
#   インターネットにつながっている事。
#   dockerコマンドが使えること。

# 定数系

SERVER_IP='10.149.28.50'

# redis のサーバ立ち上げ
docker run --name gitlab-redis -d sameersbn/redis:latest

# gitlab用のMySQLの入れ物をhostmachine側に作成。
mkdir -p /var/gitlab/{mysql,git}
chmod  777 -R /var/gitlab
chcon -Rt svirt_sandbox_file_t /var/gitlab/mysql

# gitlab用のMySQLサーバ立ち上げ
docker run --name=gitlab-mysql -d \
  --env='DB_NAME=gitlabhq_production' \
  --env='DB_USER=gitlab' --env='DB_PASS=password' \
  --volume=/var/gitlab/mysql:/var/lib/mysql \
  sameersbn/mysql:latest
    
# 本丸、gitlabを立ち上げる
docker run -d --name gitlab \
  -p 10080:80 \
  -e 'GITLAB_PORT=10080' \
  -e "GITLAB_HOST=${SERVER_IP}" \
  --link gitlab-mysql:mysql \
  --link gitlab-redis:redisio \
  sameersbn/gitlab:latest

# 本来は、上記のコマンドに
# --volume=/var/gitlab/git:/home/git/data \
# というオプションがあったのだが、
# "docker log gitlab" した結果、
# 「mkdir で permission error 吐きまくる」
# とわかったため、除いている。


echo 'finished docker run for gitlab server wake up!'
echo "please click http://${SERVER_IP}:10080/ after 5 - 10 min."
