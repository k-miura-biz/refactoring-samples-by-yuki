# NCMSのマニュアル撮影用環境(SVNのメインブランチが変更されたら即時反映する環境)のDocker作成スクリプト。

# 共通系の関数群を読み込む。
. ./lib/ncms-base.bsh

# 共通関数でDockerを立ち上げる(論理名:manual, ポートの頭:4)
run_ncms_basic_container manual 4
