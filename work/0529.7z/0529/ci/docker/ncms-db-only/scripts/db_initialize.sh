#!/bin/bash -x

# まずは再起動
service mysql restart

# rpmで入れたMySQLでは「初回、カレントディレクトリの".mysql_secret"にrootパスワードを残す」とか、する。
# 末尾パスワード部分のみを取得する。
mysql_root_password=$(cat /.mysql_secret)
mysql_root_password=${mysql_root_password##*: }

# mysqlに外から入れるよう設定(二回目以降も権限系だけはふり直す)
mysql --user=root --password=${mysql_root_password} --connect-expired-password -e "SET PASSWORD FOR root@localhost=PASSWORD('ncms');"
mysql --user=root --password=ncms -e 'CREATE DATABASE IF NOT EXISTS ncms;'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO ncms@"10.149.28.%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO ncms@"172.17.%.%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO ncms@"%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO ncms@"localhost" IDENTIFIED BY "ncms";'

mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO root@"10.149.28.%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO root@"172.17.%.%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO root@"%" IDENTIFIED BY "ncms";'
mysql --user=root --password=ncms -e 'GRANT ALL PRIVILEGES ON *.* TO root@"localhost" IDENTIFIED BY "ncms";'

# 初期化用データをインポートする。
cd /tmp
unzip ./dump.zip
mysql --user=ncms --password=ncms ncms < ./*.sql
