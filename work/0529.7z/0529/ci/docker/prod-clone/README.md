# prod-clone

## What's this ?

+ NCMS本番環境(PROD)の複製を目指した、Doekcer&Chefであらわした Infrastracutre as a Code な設定群です。
+ 本番２環境をプロファイル別にわけて、ビルドします。

## 全面的に参考にしている資料

+ http://dev.classmethod.jp/server-side/docker-provisioning-use-chef/
