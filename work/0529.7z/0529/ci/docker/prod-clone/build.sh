#!/bin/bash

BASE_NAME='prod-ncms01'

IMAGE_NAME="centos:${BASE_NAME}"

# image build
docker build -t ${IMAGE_NAME} .

