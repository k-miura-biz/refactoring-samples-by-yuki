# コマンドのメモ

+ Berkshelfを使ってのパッケージ収集・更新コマンド

` berks vendor cookbooks`

+ Chef-solo実行

`chef-solo -c ./solo.rb -j ./nodes/ncms01.json`

+ レシピ一個単位でChef-solo実行

`chef-solo -c ./solo.rb -o レシピ名`

+ 新レシピ追加

`knife cookbook create 新レシピ -o ./site-cookbooks/`

+ プロキシ仕込み

```
export http_proxy=http://proxy.nintendo.co.jp:8080
export HTTP_PROXY=${http_proxy}
export ftp_proxy=${http_proxy}
export FTP_PROXY=${http_proxy}
export https_proxy=${http_proxy}
export HTTPS_PROXY=${http_proxy}
```

+ 一時的にDockerをコミットしてコピーコンテナ立ち上げる

```
docker commit ncms01 centos:pm-install-after
docker run -v $(pwd)/chef-repo:/chef-repo -d --name ncms02 -h ncms02 -t centos:pm-install-after
```
