file_cache_path "/tmp/chef-solo"
data_bag_path "/chef-repo/data_bags"
cookbook_path ["/chef-repo/cookbooks","/chef-repo/site-cookbooks"]
