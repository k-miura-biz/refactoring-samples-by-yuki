#!/bin/bash

# ホスト名指定、イメージ指定、ネーム指定で、起動。
# docker run -d --name ncms01 -h ncms01 -t centos:prod-ncms01
# docker run --name ncms01 -h ncms01 -t centos:prod-ncms01 /bin/bash
# docker run -i --name ncms01 -h ncms01 -t centos:centos6.6 /bin/bash
# docker run -i --name ncms01 -h ncms01 -t centos:prod-ncms01 /bin/bash
# docker run -i --name ncms01 -h ncms01 -t centos:centos6 /bin/bash
docker run -v ${PWD}/chef-repo:/chef-repo -d --name ncms01 -h ncms01 -t centos:prod-ncms01 
