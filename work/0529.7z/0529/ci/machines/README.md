## What's this directory ?

マシンごとの固有設定でコードに転化したものを蓄えるディレクトリです。
