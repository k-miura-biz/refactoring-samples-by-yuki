# Ubuntuで"Atom Editor"使ってる時にクリップボード共有できない問題

Ubuntuを使っており、Atomが使いたくなった…が、ppt足してapt-getする途中の「ppt足して」でエラーとなっていたため、
本家からdebパッケージ持ってきて、インストールして溜飲を落としてた。

しかし「クリップボードが他のデスクトップアプリと共有してない！(Atom内なら共有している)」ということに気づいて、
「やっぱり…正規の手段っぽいやつ(apt-getインストール)が要るなぁ」と感じ、取り組んだ。

---

## くれぐれも勘違いないようにして欲しいのは…

基本はコレ↓で行けるはずなのだ。イレギュラーケースとして説明します。

http://qiita.com/sudix/items/4e4e1bed2f9cf257e692

## まずは「コケてたところ」まで再現。

```bash
sudo add-apt-repository ppa:webupd8team/atom
...
softwareproperties.ppa.PPAException: 'Error reading https://launchpad.net/api/1.0/~webupd8team: [Errno 111] 接続を拒否されました'
```

これなんですよ。これ。

## 軽くあがく

で「登録をコマンド経由じゃなくて、直書きならいけるんじゃね？」と思って、/etc/apt 周りを弄くる。

`sudo vi /etc/apt/sources.list`

```
## k-mirua added 2015/04/13 for atom editor
deb http://ppa.launchpad.net/webupd8team/atom/ubuntu utopic main
deb-src http://ppa.launchpad.net/webupd8team/atom/ubuntu utopic main
```

sudo apt-get update すると、以下の警告を吐く。


`W: GPG エラー: http://ppa.launchpad.net utopic Release: 公開鍵を利用できないため、以下の署名は検証できませんでした: NO_PUBKEY C2518248EEA14886`

これを潰すため、以下のコマンドを発行。

`sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys C2518248EEA14886`

が、これも失敗。うーん、万事休臼か。

----

## 解決編

いろいろ調べると元凶はこれのようで…。

http://teppeis.hatenablog.com/entry/20110605/1307254225

ポート指定して、鍵を取得。

`gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv C2518248EEA14886`

apt-keyに追加。

`gpg --armor --export C2518248EEA14886 | sudo apt-key add -`

再び、apt-get update する。

 パッケージリストを読み込んでいます... 完了

お、行けた。

あとは、atom入れるだけ。

`sudo apt-get install atom`

やった！再インストール成功！！

で、新しく入れなおしたAtomを使うと…クリップボード共有できている！！
いえーいｗ これで本来の「Atom Editorの使いやすさ」を享受できるぜ。今までごめんなAtom!

## まとめっぽいの

上記のトラブルシュートでの問題は２つで、

0. Proxy必要な環境下ではppt追加を普通のやり方じゃできない
0. AtomEditorを本家debパッケージで入れるとクリップボードが共有できない…ことがある

なので、最初の時点で真剣にトラブルシュートしてたらはまらなかったことだけど…。
後続の人らにそんなハマりしてほしくないからいちおー書いとこかなーって。

## 追記

実は「sudoの仕込み変えるだけ」でいけたりするのかもしれません…。

`sudo -E add-apt-repository ppa:webupd8team/atom`

※-Eオプションは「環境変数引き継ぎ」、試してないけど別の例ならこれで片付けれた。

## おまけ

+ proxyの仕込み方

`apm config set http-proxy http://proxy.nintendo.co.jp:8080/`
