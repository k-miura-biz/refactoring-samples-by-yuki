# 移行作業

新端末が来た時に、設定したことの全記録。

※ゆくゆくはChef化したい…そのための記録として。

## 元のWindowsの出来限りの情報

※削除するわけではない,デュアルブートで残す。

+ 型番 : Toshiba Dynabook R634/M (
  + 注文時にカスタムしまくってるのか原型がない…


+ BIOS : kccs0000
+ HDD : kccs0001
+ User : KCCSAUTH\kps2gid05_nw
+ Pass : Kccskps2gid05_n
+ Host :HPC008107
+ Domain(windows) : kccs.auth



## UbuntuサイドのTODO

+ ○  プロキシ設定 proxy.nintendo.co.jp:8080
+ ○ デスクトップの設定(アイコン小さくするとか、バーが引っ込むとか)
+ ○ nautilusえの設定
+ ○ W:ドライブのアレとかSMBサーバの設定
+ ○ Pidginインストール＆設定 ZVxWURrTDF

  + 証明書の追加の仕方

    再度設定する際(チャットサーバを作りなおしたとか)の場合、 https://10.149.28.60:7443/ のページを表示、そこで証明書を取ってPidginの証明書へ追加。

+ ○ ディレクトリ英語化
+ ○ 日本語化 http://www.server-world.info/query?os=Ubuntu_14.04&p=japanese
+ 旧端末からファイル持ってくる
+ ○ host名変更(hostnameコマンド、hostnameファイル、hosts)

このサイトを参考に、あれです。 http://kaede.blog.abk.nu/hostname

+ ○ ユーザ名変更(新規ユーザ)
+ ○ 暗号化できているかの確認 - adduserによりユーザ作り直し

  + passphrase: Kccskps2gid05_n
  + 得られたHASH : de988d673a18f4968e6ebad4172ef045


+ ○svn git 入れる
+ ○Thunderbird設定
+ ○mysqlのインストール
+ ○Java8のインストール
+ ○Maven3のインストール
+ ○ eclispeのインストール

  + http://ubuntuhandbook.org/index.php/2014/06/install-latest-eclipse-ubuntu-14-04/
  + Pleadesをあとづけで入れた（安定版をコピーで）
  + TomcatPluginは自力で入れた。 http://java-reference.sakuraweb.com/java_env_eclipsetomcat.html

+ ○ eclipse 日本語化

日本語化がうまく行かなかったので、下記URLを参考に対応

+ http://d.hatena.ne.jp/masa_m_0074/20150112/+
+ http://qiita.com/bn_naoyuki/items/322cbb67b8768e210fde
+ http://namakemono345.com/kichijitsu/ubuntu/TrustyTahr/eclipse.html

+ ○ tomcat インストール

sudo apt-get install tomcat6 で、初期起動がこけたので、以下のサイトの後半部の対応をする。

http://dicdoc.wpblog.jp/ubuntu%E3%81%A7tomcat7%E3%82%92%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%97%E3%80%81eclipse%E3%81%A7%E8%B5%B7%E5%8B%95-memo/

http://d.hatena.ne.jp/absj31/20120930/1349007029


+ ▲プリンタの追加

ちょーど現場のプリンタ「だけ」がラインナップから漏れている。諦め。

+ ○ Excelのインストール

右記のやり方を完コピ http://d.hatena.ne.jp/rideonshooting/20141122/1416661075

失敗も込みで完コピ。途中winbindを求められたので、 sudo apt-get install winbind した。

+ ○mysqlの設定

Dockerの my.conf と合成。

以下の設定をそのまま流して、設定。

http://10.121.16.127/svn/shopchannel/ncms/trunk/tools/ci/docker/ncms-base/scripts/startup.sh

+ ○データベースインポート    ｗ

Jenkinsサーバからデータ持ってきて、Mysqlに流しこむ。

scp k-miura@10.149.28.60:/home/jenkins/datapool/manual_20150319.zip /home/kps2gid05_nw/Downloads/

unzip manual_20150319.zip

mysql --user=ncms --password=ncms ncms < ncms.sql

+ ○プロジェクトを動かせる状態までにする。

ドハマリしたので、Eclipseに読める形に、Tocmat側の設定を変更した。

http://dicdoc.wpblog.jp/ubuntu%E3%81%A7tomcat7%E3%82%92%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%97%E3%80%81eclipse%E3%81%A7%E8%B5%B7%E5%8B%95-memo/

http://d.hatena.ne.jp/absj31/20120930/1349007029

+ ○TimeServerのセット

ここをそのまま設定 http://hatcy840.hatenablog.com/entry/2013/09/17/001212

サーバ名は例により、 ntp.nintendo.co.jp

+ ○ターミナルのカスタマイズ
+ ○Atomエディタをいれる

http://qiita.com/sudix/items/4e4e1bed2f9cf257e692

…ってかいてあったけど、今回はDebパッケージで入れた。

https://atom.io/

入れてからの設定。
ca  
MarkdownPreview周りがバッケ化けだったため、以下を参考にスタイルシート設定。(Migu M1指定で)

http://qiita.com/meron1219/items/1d7229acda31a819fdd4

+ ○rubyを入れる(aptで)

apt-get install ruby でインストール。

+ ○タッチパッドの無効化

ここを参考に設定。 http://ubuntuapps.blog67.fc2.com/blog-entry-697.html

```
sudo -E add-apt-repository ppa:atareao/atareao
sudo apt-get update
sudo apt-get install touchpad-indicator
```

-E を指定しているのは「add-apt-repositoryのみ、絶望的にProxyを読まない」ので強制的に環境変数を送り込んでいる。

設定ダイアログがシステムエラーになる(Synapticを期待している？)ので、とりあえずスタートアップに登録だけしといて、気になったらその時メニューから無効化している運用(あんまり良くない).


+ ○セキュリティソフトインストール

clamAV を導入、clamTKもインストールし、昼休みに更新とスキャンを行うように設定。

+ ○スタートアップ仕込み

gnome-session-properties で自動起動設定ダイアログが出せるので、それで登録。

+ ○SVNのGUIアプリを探す。

とりあえず、以前つかったことのある「RapidSVN」と、Tottasみたいな「nautilussvn」を使うこととする。

http://masaoo.blogspot.jp/2009/09/ubuntu-subversion-gui.html
http://d.hatena.ne.jp/Tnzk/20090104/1231083203

実際に入れようとすると「rabbitvcs-coreはもうなくて、rabbitvcs-coreに統合された」って言ってくるので、それに置き換え。

```
sudo apt-get install rapidsvn
sudo apt-get install rabbitvcs-nautilus rabbitvcs-gedit rabbitvcs-cli
```
Tortasみたいに「Nautilsuからディレクトリみたらチェック付いている」にできたので、御の字かなー。

+ ○Mysqlのクライアントを探す＆インストール

  いくつか見繕う

  + mysql-workbentch

    いつもの。激重なので今回は入れてない。

  + emma

    めちゃくちゃ軽いMySQL専用クライアント

    sudo apt-get install emma

    が、残念ながら「日本語がどう頑張っても読めない」のは…なんか手がないかなぁ。

  + Tora

    マルチSQL対応クライアント…らしいが。

    `sudo apt-get install libqt4-sql-mysql libqt4-sql-psql libqt4-sql-sqlite libqt4-sql-odbc libqt4-sql-tds tora`

    これもアホみたいに軽かったので、しばらくはこれで行こうと思う。

+ nautilus(ファイラ)に「このディレクトリでターミナルを上げる」など付加機能をつける

ここにこんな情報が！ (あわしろいくやさんに聞いたときになかったのに…うれしい！)

http://askubuntu.com/questions/207442/how-to-add-open-terminal-here-to-nautilus-context-menu

```
sudo apt-get install nautilus-open-terminal
sudo apt-get install nautilus-actions
```

+ 細かな「日常で使う便利コマンド」をインストール

```
sudo apt-get install gimp gnome-clocks stopwatch convmv
```

+ p2vを狙う

## WindowsサイドTODO

+ ○Ext4読めるようにする  http://ankyo.blog.so-net.ne.jp/2011-04-04
+ Ext4の暗号化を解除できる道具を探す


## Windows側のイメージ化 & Ubuntu側での再生

### 参考サイト

+ http://www1.ark-info-sys.co.jp/support/labo/vhdboot/setvirtualpc.html
+ http://memo-log.9999ch.com/2011/04/18/539 (結局問題はこれではなかった)
+ http://www.climb.co.jp/blog_vmware/hyper-v-5380
+ http://news.mynavi.jp/articles/2012/11/15/letswindows8/
+ https://technet.microsoft.com/ja-jp/magazine/ee835740.aspx (VHD周り)
+ http://kb.seeck.jp/archives/4937 (VHDを切断するTIPS)
+ https://technet.microsoft.com/ja-jp/magazine/ee835740.aspx
+ http://blogs.technet.com/b/jonjor/archive/2011/10/04/vm-does-not-boot-following-p2v-or-disk2vhd.aspx
+ http://hack.aipo.com/archives/5738/
+ http://mikasaphp.net/easy_bcd.html
+ http://www.ipentec.com/document/document.aspx?page=windows-server-2012-hyper-v-convert-from-vhd-to-vhdx
+ http://ja.wikipedia.org/wiki/VirtualBox
+ http://d.hatena.ne.jp/yao3/20100310/1268185868
+ http://anopara.matrix.jp/2013/12/22/virtualbox%E3%81%A7windows%E3%83%9E%E3%82%B7%E3%83%B3%E3%82%92p2v%E3%81%99%E3%82%8B%E3%81%A8%E3%81%8D%E3%81%AE%E6%B3%A8%E6%84%8F%E7%82%B9/
+ http://d.hatena.ne.jp/ogawad/20101029/1288309146
+ http://d.hatena.ne.jp/ogawad/20101026/1288047295
+ https://technet.microsoft.com/ja-jp/sysinternals/ee656415.aspx 本家
