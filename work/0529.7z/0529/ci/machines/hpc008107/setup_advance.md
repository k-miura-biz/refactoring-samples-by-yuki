# 続・セットアップ

## アニメーションGifで画面キャプチャ、道具インストール

ここのやりかたを真似て、画面操作のアニメGifを作る環境を整える。

+ http://polamjag.hatenablog.jp/entry/2015/02/09/003729
+ 本家ページ : http://www.maartenbaert.be/simplescreenrecorder/
+ コーデック・再生周り : http://ubuntuapps.blog67.fc2.com/blog-entry-695.html

```bash
sudo -E add-apt-repository ppa:maarten-baert/simplescreenrecorder
sudo apt-get update -y
sudo apt-get install simplescreenrecorder -y
```

少し本題とそれるが、コーデックパックと変換ツールもこのタイミングで入れておく。

```
sudo apt-get install ubuntu-restricted-extras graphicsmagick -y
sudo -E apt-add-repository ppa:samrog131/ppa
sudo apt-get update
sudo apt-get install ffmpeg-real
echo 'export PATH=${PATH}:/opt/ffmpeg/bin' >> ~/.bashrc
```

で、最後に紹介ページにあったスクリプトを取得して、動かすと。

```
simplescreenrecorder
./video2gif screencast-2015-04-14_11.45.27.mkv 8
```

…エンコード遅いし、わけわからん画像の大きさにならね？
コレなら動画で連携したほうがかなりいい！と思った三浦でした。

## 別解：アニメーションGifで画面キャプチャ、道具インストール

上のがひどくやりにくく「もっと簡単じゃね？」ってのがあったので、入れてみる。

http://labs.timedia.co.jp/2013/01/gifubuntu.html

```
sudo apt-get install  byzanz
```

これだけでは「画面指定を引数で」しなくちゃいけなく、その材料もどう取っていいかわからないため、
以下みたいなやり方をする。

```
xwininfo # ここでウィンドウを指定し、情報を取得する
byzanz-record -d 180 -x 1379 -y 234 -w 1008 -h 722 test2.gif # その情報を元にキャプチャを始める。(終了したくなったらCtrl+c)
```

将来的にはこの一連の流れを自動でやるようなスクリプトを作成したい。


## Amazonの検索とか「余計なお世話」を殺す

ここを参考に、Canonical社が商売のためにやってる系のものを全殺し。

http://ubuntuapps.blog67.fc2.com/blog-entry-695.html

設定 -> セキュリティとプライバシー -> 検索タグ -> Dashで検索するとき を オフにする。

## タスクバーに「ヘルスチェック用インジケータ」を表示

http://ubuntuapps.blog67.fc2.com/blog-entry-636.html

```sudo apt-get install indicator-multiload```

あとは,自動起動に上記コマンドを登録すればOK.


## Swapファイルを追加。

どーもメモリが爆発してフリーズ->しぶしぶ電源OFFが続いたので、少しでも緩和になればとSwap設定する。

以下を参考に。

http://www.marthaxmartha.com/2013/05/26/9963/

```
cat /proc/swaps
sudo mkdir -p /var/swap
sudo dd if=/dev/zero of=/var/swap/swap bs=2M count=4096
sudo chmod 600 /var/swap/swap
sudo mkswap /var/swap/swap
sudo swapon /var/swap/swap
sudo vi /etc/fstab
```

で、末尾に以下を追加。

`/var/swap/swap0 swap swap defaults 0 0`

あとは再起動して、cat /proc/swaps なり fd なり、たたくがよろし。

## 拡張子から起動するアプリケーションの関連付け

以下を参考に。

http://pctonitijou.blog.fc2.com/blog-entry-230.html

「拡張子から起動するアプリを変更」はGUIでできるが「そもそも選択肢が無い」に関しては対応していない。

Gnomeのファイルを変更することにより選択肢は増やせる。

```
sudo vi /etc/gnome/defaults.list
```

詳細はよくわからないが、"application/[mime名]=[アプリ名].desktop"というやり方で増える模様。
