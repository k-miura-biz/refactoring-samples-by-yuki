# ncms-server-002 server settings

## What's this ?

NCMSのサーバ二号機のインフラをコード化したものです。

## 参考

主に、このサイトから拝借しました。

http://qiita.com/futoase/items/3bf941985891f7d69a06
