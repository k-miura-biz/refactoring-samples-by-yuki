#
# Cookbook Name:: docker-customize
# Recipe:: default
#
# Copyright 2015, kccs
#
# All rights reserved - Do Not Redistribute

# 設定ファイルをコピー
cookbook_file "/etc/sysconfig/docker" do
  mode 00644
end


