file_cache_path "/tmp/chef-solo"
cookbook_path ["/root/setup/ci/machines/ncms-server-002/chef-repo/cookbooks", "/root/setup/ci/machines/ncms-server-002/chef-repo/site-cookbooks"]
role_path "roles"
log_level :info # debug
