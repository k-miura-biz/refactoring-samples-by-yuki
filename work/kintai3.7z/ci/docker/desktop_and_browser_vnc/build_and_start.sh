#!/bin/bash

BASE_NAME='desktop_and_browsser_vnc'

IMAGE_NAME="centos:${BASE_NAME}"

CONTAINER_NO='X'
CONTAINER_NAME="${BASE_NAME}_${CONTAINER_NO}"

# image build
docker build -t ${IMAGE_NAME} .

# container run
# 注:vncポートだけは「コンテナの番号での付替え」を行わず、そのまま外出し。(つまり、同一マシン内に複数存在できないということ)
docker run -d --name ${CONTAINER_NAME} -i -p 65022:22 -p 64444:4444 -p 5901:5901 -t ${IMAGE_NAME}
