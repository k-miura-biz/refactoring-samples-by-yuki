#!/bin/bash -x

# CentOSによりパッケージでインストールされるFirefoxを
# 「本家サイトの最新版」で上書きするスクリプト。

# 定数「Firefoxのサイトの日本語版のダウンロード口」
DL_FIREFOX_URL_JP='http://download.cdn.mozilla.net/pub/mozilla.org/firefox/releases/latest/linux-x86_64/ja/'
# firefoxのライブラリ群を置いてあるディレクトリ
LIB_DIR=/usr/lib64

# Webにつなげるよう、細工
export http_proxy proxy.nintendo.co.jp:8080
export HTTP_PROXY ${http_proxy}

# 最新のFirefoxのバージョンを取得する。
curl ${DL_FIREFOX_URL_JP} | grep '<a href="firefox-3' | sed -e 's/.*bz2">//g' | sed -e 's/<\/a.*//g' > latest_archive_filename.txt

# 最新をダウンロードする。
latest=`cat latest_archive_filename.txt`
curl ${DL_FIREFOX_URL_JP}${latest} > ./${latest}

# 最新版を解凍
bunzip2 ./${latest}
tar xf ./firefox*.tar

# 元の(パッケージで入れた)firefoxは退避。
mv ${LIB_DIR}/firefox ${LIB_DIR}/firefox.org

# 今、ここで解凍したのとすり替え
mv ./firefox/ ${LIB_DIR}/firefox

