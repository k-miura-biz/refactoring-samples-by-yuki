# NCMSの受け入れテスト(＆スモークテスト)用環境のDocker作成スクリプト。

IMAGE_NAME='centos:ncms-acceptancetest'
PORT_HEAD=5
CONTAINER_SUFFIX='acceptancetest'

# 引数解析

is_delete_only=0
while getopts d OPT
do
  case $OPT in
    "d" ) is_delete_only=1 ;;
  esac
done

# 共通系の関数群を読み込む。
. ./lib/ncms-base.bsh

# まず、削除する(居なくてもそれ正常に終わる)
destroy_containler ${CONTAINER_SUFFIX} ${PORT_HEAD} 

# 「削除オンリー」フラグが指定されていたなら
if [[ ${is_delete_only} -eq 1 ]] ; then
  echo '停止削除オンリーモードなので、削除時点で終了します。'
  exit 0  
fi

# 共通関数でDockerを立ち上げる(論理名:manual, ポートの頭:4)
run_ncms_basic_container ${CONTAINER_SUFFIX} ${PORT_HEAD} ${IMAGE_NAME} 

exit 0
