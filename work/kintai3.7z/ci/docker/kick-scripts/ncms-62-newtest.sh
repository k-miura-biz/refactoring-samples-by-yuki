# NCMSの開発環境(新旧比較テストその２)のDocker作成スクリプト。

# 共通系の関数群を読み込む。
. ./lib/ncms-base.bsh

# 共通関数でDockerを立ち上げる(論理名:develop, ポートの頭:3)
run_ncms_basic_container2 newtest 62 centos:ncms-base
