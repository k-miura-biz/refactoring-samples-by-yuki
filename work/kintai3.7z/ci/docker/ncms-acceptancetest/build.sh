#!/bin/bash

# NCMSの受け入れテスト(兼スモークテスト)環境のDockerImage作成スクリプト。
# 別で作成したイメージ"ncms-base"を元に、DBにデータを読み込んだ状態で新しいイメージを作成する。

# 既定となるDBデータのファイル名(ZIP)
BASE_DB_IMAGE_ARCHIVE='/home/jenkins/datapool/manual_20150217.zip'
DEST_IMAGE_NAME='centos:ncms-acceptancetest'
SRC_IMAGE_NAME='centos:ncms-base'
TMP_CONTAINER_NAME='ncms-acceptancetest-make'
PORT_HEAD=5

# Build処理

# 共通関数でDockerを立ち上げる(論理名:manual, ポートの頭:5)
docker run -d -p ${PORT_HEAD}3306:3306 -p ${PORT_HEAD}0022:0022  --name ${TMP_CONTAINER_NAME} -t ${SRC_IMAGE_NAME}

# MySQLのサーバが立ち上がるまで、しばしお待ちを…。
sleep 120

# 初期用DBイメージを流し込んでおく
unzip $BASE_DB_IMAGE_ARCHIVE
mysql --user=ncms --password=ncms -h 127.0.0.1 -P ${PORT_HEAD}3306 ncms < ./*.sql
rm *.sql

# Dockerをタグ付きでコミット。
docker commit ${TMP_CONTAINER_NAME} ${DEST_IMAGE_NAME}

# コンテナを殺す。
docker kill  ${TMP_CONTAINER_NAME}
docker rm -f ${TMP_CONTAINER_NAME}

