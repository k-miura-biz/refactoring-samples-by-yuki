#!/bin/bash

BASE_NAME='ncms-base-for-jdk7_55'

IMAGE_NAME="centos:${BASE_NAME}"

# image build
docker build -t ${IMAGE_NAME} .

